﻿using System.Collections.Concurrent;

class Program
{
    // The shared, thread-safe collection for communication between producers and consumer
    private static readonly BlockingCollection<string> s_lineCollection = new(new ConcurrentQueue<string>());
    static async Task Main(string[] args)
    {
        try
        {
            string folderPath = Path.GetFullPath(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"../../../log/"));
            string filePath = folderPath + "out.txt";
            int numberOfThreads = 10;
            int linesPerThread = 10;
            int totalLines = numberOfThreads * linesPerThread;

            if (File.Exists(filePath))
            {
                File.Delete(filePath);
            }

            File.WriteAllText(filePath, "0, 0, " + DateTime.Now.ToString("HH:mm:ss.fff") + Environment.NewLine);

            //Start the single consumer task which writes to the file sequentially
            Task consumerTask = Task.Run(() => ConsumeAndWriteToFile(filePath));

            // Start the producer tasks in parallel
            var producerTasks = Enumerable.Range(1, numberOfThreads)
             .Select(threadId => Task.Run(() => ProduceLines(threadId, linesPerThread)))
            .ToList();

            // Wait for all producer tasks to complete
            await Task.WhenAll(producerTasks);

            // Signal to the consumer that no more items will be added
            s_lineCollection.CompleteAdding();

            // Wait for the consumer task to finish processing the remaining queue
            await consumerTask;
           
            Console.WriteLine("Press any key to exit the application!");
            Console.ReadKey();
        }
        catch (FileNotFoundException ex)
        {
            Console.WriteLine($"Error: The file was not found. {ex.Message}");
        }
        catch (IOException ex)
        {
            Console.WriteLine($"An I/O error occurred: {ex.Message}");
        }
        catch (AggregateException ex)
        {
            var flatExceptions = ex.Flatten().InnerExceptions;
            foreach (var innerEx in flatExceptions)
            {
                Console.WriteLine($"An inner exception occurred: {innerEx.Message}");
            }
        }
        catch (Exception e)
        {
            Console.WriteLine($"An error occurred: {e.Message}");
        }
    }
    // generates lines and adds them to the blocking collection
    private static void ProduceLines(int threadId, int linesPerThread)
    {
        for (int i = 0; i < linesPerThread; i++)
        {
            // The line number must be determined by the order in which the data is processed by the consumer   
            string line = $"{threadId}, {DateTime.Now:HH:mm:ss.fff}";
            s_lineCollection.Add(line);
        }
    }

    //safely writes lines to the file in order
    private static void ConsumeAndWriteToFile(string filePath)
    {
        int lineNumber = 1;
        //Use a single StreamWriter instance for thread-safe sequential writing
        using (StreamWriter writer = new(filePath, append: true))
        {
            // GetConsumingEnumerable() blocks until an item is available or CompleteAdding() is called
            foreach (var line in s_lineCollection.GetConsumingEnumerable())
            {
                writer.WriteLine($"{lineNumber++}, {line}");
            }
        }
    }
}
